/* =====================================================================
   KESTREL LIVING - AI ANSWER VALIDATION IN SQL  (T-SQL / SQL Server)
   ---------------------------------------------------------------------
   Setup: import the 5 data sheets as tables with their original column
   names: Customers, Products, Orders, Order_Lines, Returns.
   Import Orders.Order_Date as TEXT (varchar) - it mixes two formats.
   Run PART 1 first (creates 3 views), then any query in PART 2 or 3.
   Expected answers are in the comments so you can tick each one off.

   NOTE: written for SQL Server. I could not run it against a live SQL
   Server here, so check the expected values. If one differs, tell me
   which query and what you got. On MySQL / PostgreSQL / SQLite the
   date parsing and views need small changes.
   ===================================================================== */


/* =====================================================================
   PART 1 - GOVERNED DATA LAYER (the cleaning steps, as views)
   ===================================================================== */

-- 1a. Orders with real dates, tidy channel labels, and a test-account flag
CREATE VIEW vw_Orders_Clean AS
SELECT
    o.Order_ID,
    o.Customer_ID,
    o.Region,
    o.Order_Status,
    -- two date formats in the source: dd/mm/yyyy (30 rows) and yyyy-mm-dd
    CASE WHEN o.Order_Date LIKE '%/%'
         THEN TRY_CONVERT(date, o.Order_Date, 103)
         ELSE TRY_CONVERT(date, o.Order_Date, 23) END                AS Order_Date,
    -- trim spaces and standardise case:  ' Store' / 'online' -> 'Store' / 'Online'
    UPPER(LEFT(LTRIM(RTRIM(o.Sales_Channel)), 1))
      + LOWER(SUBSTRING(LTRIM(RTRIM(o.Sales_Channel)), 2, 50))       AS Sales_Channel,
    -- BR03: TEST001 / TEST002 are internal QA accounts
    CASE WHEN o.Customer_ID LIKE 'TEST%' THEN 1 ELSE 0 END           AS Is_Test
FROM Orders o;
GO

-- 1b. Order lines with the 45 exact duplicate rows removed
CREATE VIEW vw_Lines_Clean AS
SELECT DISTINCT * FROM Order_Lines;
GO

-- 1c. In-scope lines = Completed orders only, test accounts excluded (BR01-BR03)
CREATE VIEW vw_Scope AS
SELECT
    l.*,
    o.Customer_ID,
    o.Region,
    o.Sales_Channel,
    o.Order_Date,
    CONVERT(char(7), o.Order_Date, 126) AS Order_Month          -- 'yyyy-mm'
FROM vw_Lines_Clean l
JOIN vw_Orders_Clean o ON o.Order_ID = l.Order_ID
WHERE o.Order_Status = 'Completed'
  AND o.Is_Test = 0;
GO


/* =====================================================================
   PART 2 - DATA QUALITY CHECKS (evidence for the Data_Quality_Log)
   ===================================================================== */

-- 2a. Find the duplicate lines. Expect 45 Order_Line_IDs, each appearing twice
SELECT Order_Line_ID, COUNT(*) AS copies
FROM Order_Lines
GROUP BY Order_Line_ID
HAVING COUNT(*) > 1;

-- 2b. Row counts. Expect 60,070 raw, 60,025 after removing duplicates
SELECT (SELECT COUNT(*) FROM Order_Lines)    AS raw_rows,
       (SELECT COUNT(*) FROM vw_Lines_Clean) AS clean_rows;

-- 2c. Why we believe they are duplicates: the Returns table agrees only after removal
--     Expect Returns table = 5,307 | clean lines = 5,307 | raw lines = 5,313
SELECT (SELECT SUM(Quantity_Returned) FROM Returns)         AS returns_table_units,
       (SELECT SUM(Quantity_Returned) FROM vw_Lines_Clean)  AS clean_line_units,
       (SELECT SUM(Quantity_Returned) FROM Order_Lines)     AS raw_line_units;

-- 2d. Channel labels before cleaning (expect 9) and after (expect 3)
SELECT COUNT(DISTINCT Sales_Channel) AS raw_labels   FROM Orders;
SELECT COUNT(DISTINCT Sales_Channel) AS clean_labels FROM vw_Orders_Clean;

-- 2e. Dates that failed to parse. Expect 0 rows
SELECT Order_ID, Order_Date FROM Orders
WHERE Order_ID IN (SELECT Order_ID FROM vw_Orders_Clean WHERE Order_Date IS NULL);

-- 2f. Revenue effect of the duplicates. Expect 22,985,073.30 vs 22,965,866.60 (diff 19,206.70)
SELECT
  (SELECT SUM(l.Net_Revenue) FROM Order_Lines l
     JOIN vw_Orders_Clean o ON o.Order_ID = l.Order_ID
    WHERE o.Order_Status='Completed' AND o.Is_Test=0)   AS revenue_with_duplicates,
  (SELECT SUM(Net_Revenue) FROM vw_Scope)               AS revenue_clean;


/* =====================================================================
   PART 3 - VALIDATE EACH AI ANSWER
   ===================================================================== */

-- AI-001  Total net revenue.                          Expect 22,965,866.60  (AI correct)
SELECT SUM(Net_Revenue) AS total_net_revenue FROM vw_Scope;

-- AI-002 / AI-007  Profit by category.                Expect Furniture 2,691,128.00 top (AI correct)
SELECT Product_Category,
       SUM(Net_Revenue)                          AS net_revenue,
       SUM(Profit)                               AS profit,
       SUM(Profit) * 1.0 / SUM(Net_Revenue)      AS margin
FROM vw_Scope
GROUP BY Product_Category
ORDER BY profit DESC;
/* Expect:  Furniture 2,691,128.00 (37.8%) | Bedroom 2,516,991.75 (36.0%) | Outdoor 1,854,836.50 (44.0%)
            Kitchen & Dining 1,183,234.15 (53.8%) | Lighting 1,001,207.20 (54.3%) | Home Décor 368,950.00 (62.4%)
   AI-013: Home Décor has the lowest profit but the HIGHEST margin; Bedroom has the lowest margin. */

-- AI-003  Completed orders.                           Expect 21,331  (AI correct)
SELECT COUNT(DISTINCT Order_ID) AS completed_orders FROM vw_Scope;
-- naive count that forgets the test accounts: expect 21,339
SELECT COUNT(*) AS naive_completed FROM Orders WHERE Order_Status = 'Completed';

-- AI-004  Return rate by quantity.                    Expect 4.98% (5,305 / 106,451). AI said 7.4% = WRONG
SELECT SUM(Quantity_Returned)                         AS returned_units,
       SUM(Quantity)                                  AS sold_units,
       SUM(Quantity_Returned) * 1.0 / SUM(Quantity)   AS return_rate
FROM vw_Scope;

-- AI-005  Net revenue by channel.                     Expect Online 12,697,326.35 | Store 6,917,882.20 | Marketplace 3,350,658.05
SELECT Sales_Channel, SUM(Net_Revenue) AS net_revenue
FROM vw_Scope GROUP BY Sales_Channel ORDER BY net_revenue DESC;

-- AI-006  Net revenue by region.                      Expect North West 2,454,073.50, then Wales 2,438,751.60 (lead only 0.63%)
SELECT Region, SUM(Net_Revenue) AS net_revenue
FROM vw_Scope GROUP BY Region ORDER BY net_revenue DESC;

-- AI-008  Cancelled orders' revenue.                  Expect 2,125,821.15 de-duplicated (AI used 2,127,346.65 incl. duplicates)
--         The right answer is still NO: cancelled orders must be excluded from completed sales (BR01)
SELECT SUM(l.Net_Revenue) AS cancelled_revenue_clean
FROM vw_Lines_Clean l JOIN vw_Orders_Clean o ON o.Order_ID = l.Order_ID
WHERE o.Order_Status = 'Cancelled';
SELECT SUM(l.Net_Revenue) AS cancelled_revenue_with_duplicates
FROM Order_Lines l JOIN vw_Orders_Clean o ON o.Order_ID = l.Order_ID
WHERE o.Order_Status = 'Cancelled';

-- AI-009  Net revenue by month.                       Expect 2025-01 2,029,147.95 top, then 2025-03 2,017,364.60
SELECT Order_Month, SUM(Net_Revenue) AS net_revenue
FROM vw_Scope GROUP BY Order_Month ORDER BY net_revenue DESC;

-- AI-010  Does marketing consent mean higher spend?   Expect Yes 5,699.58 (1,979 cust) vs No 5,782.48 (2,021 cust)
--         Consenters spend slightly LESS; AI claim is WRONG, and causation cannot be shown (BR06)
;WITH spend AS (
    SELECT Customer_ID, SUM(Net_Revenue) AS spend FROM vw_Scope GROUP BY Customer_ID
)
SELECT c.Marketing_Consent,
       COUNT(*)                          AS customers,
       AVG(COALESCE(s.spend, 0))         AS avg_spend   -- customers with no orders count as 0
FROM Customers c
LEFT JOIN spend s ON s.Customer_ID = c.Customer_ID
WHERE c.Customer_Segment <> 'Internal Test'
GROUP BY c.Marketing_Consent;

-- AI-011 / AI-015  Top-10 spenders and the consent gate (IDs only - no names or emails)
--         Expect 3 of 10 have consent = Yes. The other 7 must NOT be contacted (BR07, BR08)
SELECT TOP 10 s.Customer_ID,
       SUM(s.Net_Revenue)                                   AS spend,
       c.Marketing_Consent,
       CASE WHEN c.Marketing_Consent = 'Yes' THEN 'May contact'
            ELSE 'BLOCK - no consent' END                   AS outreach_decision
FROM vw_Scope s
JOIN Customers c ON c.Customer_ID = s.Customer_ID
GROUP BY s.Customer_ID, c.Marketing_Consent
ORDER BY spend DESC;

-- AI-012  Profit.                                     Expect 9,616,347.60. AI said 22,965,866.60 (= revenue) WRONG
SELECT SUM(Net_Revenue) AS net_revenue,
       SUM(Cost)        AS cost,
       SUM(Profit)      AS profit,
       SUM(Profit) * 1.0 / SUM(Net_Revenue) AS margin      -- 41.9%
FROM vw_Scope;

-- AI-014  Are returns the main gap between gross and net revenue?
--         Expect gross 24,314,576.00 | discounts 1,348,709.40 (5.5%) | returns value 1,159,265.95 (4.8%)
--         Net_Revenue already excludes discounts but NOT returns, so the gross-to-net gap is 100% discounts.
SELECT SUM(Gross_Revenue)                                           AS gross_revenue,
       SUM(Discount_Amount)                                         AS discounts,
       SUM(Net_Revenue)                                             AS net_revenue,
       SUM(Quantity_Returned * Net_Revenue / Quantity)              AS returned_value,
       SUM(Net_Revenue) - SUM(Quantity_Returned * Net_Revenue / Quantity) AS return_adjusted_revenue,
       SUM(Discount_Amount)    * 1.0 / SUM(Gross_Revenue)           AS discount_pct_of_gross,
       SUM(Quantity_Returned * Net_Revenue / Quantity) * 1.0 / SUM(Gross_Revenue) AS returns_pct_of_gross
FROM vw_Scope;


/* =====================================================================
   PART 4 - THE CHECKING MECHANISM (works beyond the 15 examples)
   Store each AI claim in a table, recompute it, flag the mismatch.
   To validate a new answer, add one row to the claims table and one
   row to the validated CTE.
   ===================================================================== */

CREATE TABLE AI_Claims (
    Query_ID      varchar(10),
    Metric        varchar(40),
    AI_Value      decimal(18,4),
    AI_Confidence int
);

INSERT INTO AI_Claims VALUES
 ('AI-001', 'Net Revenue',      22965866.60, 96),
 ('AI-003', 'Completed Orders', 21331,       92),
 ('AI-004', 'Return Rate',      0.074,       91),
 ('AI-012', 'Profit',           22965866.60, 94);

;WITH validated AS (
    SELECT 'Net Revenue'      AS Metric, SUM(Net_Revenue)            * 1.0 AS Value, 0.5    AS Tolerance FROM vw_Scope
    UNION ALL
    SELECT 'Completed Orders',           COUNT(DISTINCT Order_ID)    * 1.0,          0.5                 FROM vw_Scope
    UNION ALL
    SELECT 'Profit',                     SUM(Profit)                 * 1.0,          0.5                 FROM vw_Scope
    UNION ALL
    SELECT 'Return Rate',                SUM(Quantity_Returned) * 1.0 / SUM(Quantity), 0.0005            FROM vw_Scope
)
SELECT a.Query_ID,
       a.Metric,
       a.AI_Value,
       v.Value                       AS Validated_Value,
       a.AI_Value - v.Value          AS Difference,
       a.AI_Confidence,
       CASE WHEN ABS(a.AI_Value - v.Value) <= v.Tolerance THEN 'PASS'
            ELSE 'FAIL - reject and route to Senior Analyst' END AS Check_Result
FROM AI_Claims a
JOIN validated v ON v.Metric = a.Metric;
/* Expect: AI-001 PASS | AI-003 PASS | AI-004 FAIL (0.074 vs 0.0498) | AI-012 FAIL (off by 13,349,519.00)
   Note the confidence column: the two FAILs scored 91 and 94. Confidence is not evidence. */
